// ======================
// DARK MODE
// ======================

const themeBtn = document.getElementById("theme-btn");


themeBtn.onclick = () => {

    document.body.classList.toggle("dark");


    if(document.body.classList.contains("dark")){

        themeBtn.innerHTML = "☀️";

    } else {

        themeBtn.innerHTML = "🌙";

    }

};






// ======================
// BACK TO TOP BUTTON
// ======================


const topBtn = document.getElementById("top");


window.addEventListener("scroll",()=>{


    if(window.scrollY > 400){

        topBtn.style.display="block";

    }else{

        topBtn.style.display="none";

    }


});



topBtn.onclick = ()=>{


window.scrollTo({

top:0,
behavior:"smooth"

});


};







// ======================
// CUSTOM CURSOR
// ======================


const cursor =
document.querySelector(".cursor");



document.addEventListener("mousemove",(e)=>{


cursor.style.left =
e.clientX + "px";


cursor.style.top =
e.clientY + "px";


});








// ======================
// SCROLL REVEAL ANIMATION
// ======================


const revealElements =
document.querySelectorAll(
".section, .card, .skill"
);



const observer =
new IntersectionObserver((entries)=>{


entries.forEach(entry=>{


if(entry.isIntersecting){


entry.target.style.opacity="1";

entry.target.style.transform=
"translateY(0)";


}


});


});





revealElements.forEach(element=>{


element.style.opacity="0";

element.style.transform=
"translateY(50px)";


element.style.transition=
"0.8s ease";


observer.observe(element);


});








// ======================
// NAV ACTIVE EFFECT
// ======================


const links =
document.querySelectorAll("nav a");



links.forEach(link=>{


link.addEventListener("click",()=>{


links.forEach(item=>{


item.style.color="";


});



link.style.color="#8b5cf6";


});


});








// ======================
// PROJECT HOVER EFFECT
// ======================


const cards =
document.querySelectorAll(".card");



cards.forEach(card=>{


card.addEventListener("mouseenter",()=>{


card.style.boxShadow =
"0 25px 60px #8b5cf655";


});



card.addEventListener("mouseleave",()=>{


card.style.boxShadow =
"0 15px 35px #0002";


});


});








// ======================
// SKILL BAR ANIMATION
// ======================


const bars =
document.querySelectorAll(".bar div");



const barObserver =
new IntersectionObserver((entries)=>{


entries.forEach(entry=>{


if(entry.isIntersecting){


entry.target.style.width =
entry.target.style.width;


}


});


});



bars.forEach(bar=>{

barObserver.observe(bar);

});
